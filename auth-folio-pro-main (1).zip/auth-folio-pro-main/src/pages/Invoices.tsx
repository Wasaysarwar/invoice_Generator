import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Search, Filter, FileText, Download, Eye } from "lucide-react";
import { CreateInvoiceDialog } from "@/components/CreateInvoiceDialog";
import { ThemeToggle } from "@/components/ThemeToggle";

const Invoices = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const invoices = [
    { id: "INV-001", client: "Tech Corp", amount: "$2,500", status: "paid", category: "development", date: "2025-10-28", dueDate: "2025-11-28" },
    { id: "INV-002", client: "Design Studio", amount: "$1,800", status: "pending", category: "design", date: "2025-10-27", dueDate: "2025-11-27" },
    { id: "INV-003", client: "Marketing Agency", amount: "$3,200", status: "paid", category: "consulting", date: "2025-10-25", dueDate: "2025-11-25" },
    { id: "INV-004", client: "Startup Inc", amount: "$4,500", status: "overdue", category: "development", date: "2025-10-20", dueDate: "2025-10-30" },
    { id: "INV-005", client: "Creative Co", amount: "$2,100", status: "paid", category: "design", date: "2025-10-18", dueDate: "2025-11-18" },
    { id: "INV-006", client: "E-commerce Ltd", amount: "$5,800", status: "pending", category: "marketing", date: "2025-10-15", dueDate: "2025-11-15" },
    { id: "INV-007", client: "Finance Group", amount: "$3,900", status: "paid", category: "consulting", date: "2025-10-12", dueDate: "2025-11-12" },
    { id: "INV-008", client: "Health Tech", amount: "$6,200", status: "pending", category: "development", date: "2025-10-10", dueDate: "2025-11-10" },
  ];

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      development: "bg-category-development",
      design: "bg-category-design",
      consulting: "bg-category-consulting",
      marketing: "bg-category-marketing",
      other: "bg-category-other"
    };
    return colors[category] || "bg-muted";
  };

  const getStatusVariant = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      paid: "default",
      pending: "secondary",
      overdue: "destructive"
    };
    return variants[status] || "outline";
  };

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         invoice.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "all" || invoice.category === categoryFilter;
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const categoryStats = {
    all: invoices.length,
    development: invoices.filter(i => i.category === "development").length,
    design: invoices.filter(i => i.category === "design").length,
    consulting: invoices.filter(i => i.category === "consulting").length,
    marketing: invoices.filter(i => i.category === "marketing").length,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Link to="/dashboard">
            <Button variant="ghost" size="sm" className="mb-2">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Invoice History</h1>
                <p className="text-sm text-muted-foreground">
                  {filteredInvoices.length} of {invoices.length} invoices
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle />
              <CreateInvoiceDialog />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Category Filter Pills */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold mb-3 text-muted-foreground">Filter by Category</h3>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={categoryFilter === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter("all")}
            >
              All ({categoryStats.all})
            </Button>
            <Button
              variant={categoryFilter === "development" ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter("development")}
              className={categoryFilter === "development" ? "" : "border-category-development/30"}
            >
              <div className={`w-2 h-2 rounded-full ${getCategoryColor("development")} mr-2`} />
              Development ({categoryStats.development})
            </Button>
            <Button
              variant={categoryFilter === "design" ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter("design")}
              className={categoryFilter === "design" ? "" : "border-category-design/30"}
            >
              <div className={`w-2 h-2 rounded-full ${getCategoryColor("design")} mr-2`} />
              Design ({categoryStats.design})
            </Button>
            <Button
              variant={categoryFilter === "consulting" ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter("consulting")}
              className={categoryFilter === "consulting" ? "" : "border-category-consulting/30"}
            >
              <div className={`w-2 h-2 rounded-full ${getCategoryColor("consulting")} mr-2`} />
              Consulting ({categoryStats.consulting})
            </Button>
            <Button
              variant={categoryFilter === "marketing" ? "default" : "outline"}
              size="sm"
              onClick={() => setCategoryFilter("marketing")}
              className={categoryFilter === "marketing" ? "" : "border-category-marketing/30"}
            >
              <div className={`w-2 h-2 rounded-full ${getCategoryColor("marketing")} mr-2`} />
              Marketing ({categoryStats.marketing})
            </Button>
          </div>
        </div>

        {/* Search and Filter Bar */}
        <Card className="border-border/50 mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by client name or invoice number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Invoices Grid */}
        <div className="grid gap-4">
          {filteredInvoices.map((invoice) => (
            <Card key={invoice.id} className="border-border/50 hover:shadow-md transition-all">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-16 rounded-full ${getCategoryColor(invoice.category)}`} />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{invoice.id}</h3>
                        <Badge variant={getStatusVariant(invoice.status)}>
                          {invoice.status}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground">{invoice.client}</p>
                      <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                        <span>Issued: {invoice.date}</span>
                        <span>Due: {invoice.dueDate}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-2xl font-bold">{invoice.amount}</div>
                      <div className="text-xs text-muted-foreground capitalize">
                        {invoice.category}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredInvoices.length === 0 && (
          <Card className="border-border/50">
            <CardContent className="py-12 text-center">
              <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No invoices found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search query
              </p>
              <Button variant="outline" onClick={() => {
                setSearchQuery("");
                setCategoryFilter("all");
                setStatusFilter("all");
              }}>
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default Invoices;
